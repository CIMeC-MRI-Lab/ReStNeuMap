%main_LN
GUI_LN
clear all
%fromAtlastoSubj_aut_job(atlasdir)
%extractcomponent_auto