NOTE:  These scripts are old and not supported. They are provided as example batch scripts for estimating a GLM and checking the quality of group results.

---------------------------------------------------------
README for estiscript for SPM5

Put this folder in your matlab path.

Copy the following programs to your script directory
  estiscript5.m
  estimatemodel.m
and modify them by the directions in the code.

The code assumes:
 1. subject folder contains image folders and results folders
 2. each image folder is a session
 3. each session will be realigned separately.
 4. the results can include multiple sessions....
