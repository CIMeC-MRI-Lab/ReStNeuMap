function alpha_splash();

clc

fprintf('%-4s\n','   __  _   ___ _       __         ');
fprintf('%-4s\n',' / _ \| | | - | |__  / _ \        ');
fprintf('%-4s\n','|  _  | |_|  /|  _  \  _  |       ');
fprintf('%-4s\n','|_| |_|___|_| |_| |_|_| |_| v1.0  ');
fprintf('%-4s\n','   S   C   R   I   P   T          ');

return;
