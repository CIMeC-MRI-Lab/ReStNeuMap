%-----------------------------------------------------------------------
% Job saved on 15-Dec-2017 11:25:16 by cfg_util (rev $Rev: 6134 $)
% spm SPM - SPM12 (6225)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.spatial.coreg.write.ref = {'\\cimec-storage3\MUMI\Domenico_Zaca\clinicalRSdata\september15analysis_scripts\DataperAbstracrt\RSfMRI_SAB_04_78\PA0\ST0\SE1\ProcessDir\AbstractData\icacommand\Sanfilippo_Brigitte_T1.nii,1'};
matlabbatch{1}.spm.spatial.coreg.write.source = {
                                                 '\\cimec-storage3\MUMI\Domenico_Zaca\clinicalRSdata\september15analysis_scripts\DataperAbstracrt\RSfMRI_SAB_04_78\PA0\ST0\SE1\ProcessDir\AbstractData\icacommand\lang_auto_thr.nii,1'
                                                 '\\cimec-storage3\MUMI\Domenico_Zaca\clinicalRSdata\september15analysis_scripts\DataperAbstracrt\RSfMRI_SAB_04_78\PA0\ST0\SE1\ProcessDir\AbstractData\icacommand\motor_auto_thr.nii,1'
                                                 };
matlabbatch{1}.spm.spatial.coreg.write.roptions.interp = 4;
matlabbatch{1}.spm.spatial.coreg.write.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.coreg.write.roptions.mask = 0;
matlabbatch{1}.spm.spatial.coreg.write.roptions.prefix = 'rT1_';
